public class PrimeNumberChecker {
    public static void main(String[] args) {
        int number = 29;
        boolean isPrime = isPrime(number);

        System.out.println(number + (isPrime ? " is prime." : " is not prime."));
    }

    static boolean isPrime(int number) {
        if (number < 2) {
            return false;
        }

        for (int divisor = 2; divisor <= Math.sqrt(number); divisor++) {
            if (number % divisor == 0) {
                return false;
            }
        }

        return true;
    }
}
