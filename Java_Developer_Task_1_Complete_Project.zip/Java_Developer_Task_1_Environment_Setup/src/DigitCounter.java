public class DigitCounter {
    public static void main(String[] args) {
        int number = 123456;
        int original = Math.abs(number);
        int count = (original == 0) ? 1 : 0;

        while (original > 0) {
            original /= 10;
            count++;
        }

        System.out.println("Number: " + number);
        System.out.println("Digit count: " + count);
    }
}
