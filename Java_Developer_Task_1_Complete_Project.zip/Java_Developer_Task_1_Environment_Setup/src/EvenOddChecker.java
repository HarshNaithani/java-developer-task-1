public class EvenOddChecker {
    public static void main(String[] args) {
        int number = 42;
        String result = (number % 2 == 0) ? "Even" : "Odd";

        System.out.println(number + " is " + result);
    }
}
