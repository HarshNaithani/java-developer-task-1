public class MultiplicationTable {
    public static void main(String[] args) {
        int number = 7;

        System.out.println("Multiplication table for " + number);
        for (int i = 1; i <= 10; i++) {
            System.out.printf("%d x %d = %d%n", number, i, number * i);
        }
    }
}
