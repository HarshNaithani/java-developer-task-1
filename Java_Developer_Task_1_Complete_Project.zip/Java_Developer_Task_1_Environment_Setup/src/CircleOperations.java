public class CircleOperations {
    static double area(double radius) {
        return Math.PI * radius * radius;
    }

    static double circumference(double radius) {
        return 2 * Math.PI * radius;
    }

    public static void main(String[] args) {
        double radius = 5.0;

        System.out.printf("Radius: %.2f%n", radius);
        System.out.printf("Area: %.2f%n", area(radius));
        System.out.printf("Circumference: %.2f%n", circumference(radius));
    }
}
