# Java Developer Task 1 — Environment Setup & Basic Syntax

This repository implements the ten practice programs specified in Task 1.

## Programs

1. **HelloWorld** — basic class, `main`, and console output.
2. **TemperatureConverter** — Fahrenheit to Celsius using arithmetic operations.
3. **EvenOddChecker** — modulo and ternary operator.
4. **MultiplicationTable** — `for` loop and formatted output.
5. **DigitCounter** — `while` loop and integer division.
6. **FibonacciSeries** — sequence generation and variable swapping.
7. **PrimeNumberChecker** — boolean flag, `Math.sqrt` loop bound, and early decision.
8. **DayFinder** — modern switch expression with arrow syntax.
9. **ArrayOperations** — array traversal and aggregate calculations.
10. **CircleOperations** — reusable methods and `Math.PI`.

## Environment

- JDK 17 or newer
- IntelliJ IDEA Community Edition or Eclipse
- `JAVA_HOME` configured according to the local JDK installation

Verify Java from a terminal:

```text
java -version
javac -version
```

## Compile

From the project root:

```text
javac -d out src/*.java
```

## Run

For example:

```text
java -cp out HelloWorld
java -cp out TemperatureConverter
java -cp out EvenOddChecker
java -cp out MultiplicationTable
java -cp out DigitCounter
java -cp out FibonacciSeries
java -cp out PrimeNumberChecker
java -cp out DayFinder
java -cp out ArrayOperations
java -cp out CircleOperations
```

## Expected learning outcomes

The programs demonstrate Java class structure, primitive variables, arithmetic operators, conditional logic, loops, arrays, methods, switch expressions, and basic algorithmic thinking.

## Note

The example inputs are intentionally simple and easy to verify. Review and understand each program before submission.
